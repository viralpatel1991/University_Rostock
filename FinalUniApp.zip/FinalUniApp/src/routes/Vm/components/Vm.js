import React from 'react'
import PropTypes from 'prop-types'
import './Vm.scss'
import findIndex from 'lodash/findIndex'
import Popup from 'components/Popup'
import { Col, Grid , Row, Panel, Form, FormGroup,FormControl,ControlLabel,Button,Modal} from 'react-bootstrap'


export const Vm = ({
  terminals, vms, onVmNameChange, onVmIpChange,
  onVmAdd, onVmRemove, vmName, vmIp,
  selectedVmIp, selectedVmName, error,
  onVmDetails, selectedVmData, onSelectedVmUpdate,
  onSelectedVmUpdateIp, onSelectedVmUpdateName,
  addVmPopupOpen, onAddVmPopupToggle,
  addVmConnectionsPopupOpen, onAddVmConnectionsPopupToggle,
  availableTerminals, addVmToSelectedTerminal, onTerminalToSelectedVmChange,
  onConnectedTerminalRemove, terminalToVmTerminalAddIp,
  selectedVmIpChanged, selectedVmNameChanged,
  terminalToSelectedVmAddIp, addTerminalToSelectedVm, onTerminalSelect, selectedTerminals, onTypeSelect
}) => { return (

  <div>
    <Row style={{margin:'10px 30px'}}>
      <Col md={6}  style={{height: '400px'}}>
        <Row style={{border: '1px solid #eee',height: '360px', overflowY: 'scroll', paddingLeft:'1em',paddingRight:'1em'}} >
          {vms && vms.map((vm, key) => (
            <Panel  key={key} style={{  textAlign: 'left'}}  value={vm.vmIp} >
              <label style={{  verticalAlign:'middle', paddingTop:'5px', width:'80%'}} onClick={() => {onVmDetails({ vmName: vm.vmName, vmIp: vm.vmIp })}}>{vm.vmName}</label>
              <button className='Btn' value={vm.vmIp} onClick={() => {onVmRemove({ vmName: vm.vmName, vmIp: vm.vmIp })}}>
                &#215;
              </button>
            </Panel>
          ))}
        </Row>
        <Row style={{ height: '40px',border: '1px solid #eee'}}>
          <button type='submit' className='btn btn-primary' onClick={onAddVmPopupToggle}>Add VM</button>
        </Row>
      </Col>

      <Col md={6} style={{ height: '400px'}}>
      {selectedVmName && (
        <Row style={{ border: '1px solid #eee', paddingTop:'5px',verticalAlign:'middle',height: '30px', textAlign:'center'}} >
          <strong>Detail of {selectedVmName}</strong>
        </Row>
      )}

      {selectedVmName && (
        <Row style={{paddingTop:'5px',border: '1px solid #eee'}} >
          <Col  md={5}>
            <Row style={{height: '35px'}}>
              <label>VM Name : {selectedVmName} </label>
            </Row>
            <Row style={{ height: '35px'}}>
              <label>VM Ip : {selectedVmIp}</label>
            </Row>
            <Row style={{ color: 'red'}}>
              {error && (
                error
              )}
            </Row>
          </Col>
          <Col  md={5}>
            <Row style={{height: '35px'}}>
              <input style={{ padding: '.25rem'}} className='form-control' type='text' id='vm-name' name='vmName' placeholder='update name' onChange={onSelectedVmUpdateName} value={selectedVmNameChanged} />
            </Row>
            <Row style={{ height: '35px'}}>
              <input style={{ padding: '.25rem'}} className='form-control' type='text' id='vm-ip' name='vmIp' placeholder='update IP' onChange={onSelectedVmUpdateIp} value={selectedVmIpChanged} />            
            </Row>
          </Col>
          <Col  md={2} >
              <Row style={{ verticalAlign:'middle', paddingTop:'10px'}}>
                <button type='submit' className='btn btn-primary center-block' onClick={onSelectedVmUpdate}>Submit</button>
              </Row>
          </Col>
        </Row>
      )}

      {selectedVmName && (
       <Row style={{ border: '1px solid #eee'}}>
      <Row style={{ verticalAlign:'middle', paddingTop:'5px', height: '40px',textAlign:'center'}} >
         <strong>List of connected Terminals with {selectedVmName}</strong>
        </Row>
        <Row style={{ marginLeft: '0px', marginRight:'0px'}}>
        <Col md={8} style={{ border: '1px solid #eee',height: '250px', overflowY: 'scroll'}}>
          {selectedVmData && selectedVmData.map((connection, key) => (

           <Panel key={key} style={{  textAlign: 'left'}}>
             <label style={{  verticalAlign:'middle', paddingTop:'5px'}}>{connection.terminalData.terminalName}</label>
         
            <button className='Btn' value={connection.terminalData.terminalIp} onClick={() => {onConnectedTerminalRemove({ terminalName: connection.terminalData.terminalName, terminalIp: connection.terminalData.terminalIp })}}>
              &#215;
            </button>
            </Panel>
             ))}
          </Col>
          <Col md={4}   style={{ border: '1px solid #eee',height: '250px', paddingTop:'50px',textAlign:'center'}}>
              <button className='btn btn-primary' style={{ marginTop: '10px' }} onClick={onAddVmConnectionsPopupToggle}>Add Terminal</button>
          </Col>
        </Row>
      </Row>
      )}
      </Col>


  </Row>

{typeof addVmPopupOpen === 'boolean' && (

        <Modal
          show={addVmPopupOpen}
          onHide={onAddVmPopupToggle}
          aria-labelledby="contained-modal-title"
        >
          <Modal.Header closeButton>
            <Modal.Title>Create Vm</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <Row >
            <Col sm={8}>
            <label className='form-label text-left'>Vm Name:</label>
            <input className='form-control text-left'  type='text' id='vm-name' name='vmName' onChange={onVmNameChange} value={vmName} />
            </Col>
            <Col sm={8}>
            <label>Vm Ip:</label>
            <input className='form-control' type='text' id='vm-ip' name='vmIp' onChange={onVmIpChange} value={vmIp} />
            </Col>
            </Row>

          </Modal.Body>
          <Modal.Footer>
            <Row>
            <Col sm={9}>
            <div className='text-left' style={{ color: 'red'}}>
              {error && (
                error
              )}
              </div>
            </Col>
            <Col sm={3} >
               <Button  className='btn btn-primary' onClick={onVmAdd}>Submit</Button>
            </Col>
            </Row>

           
          </Modal.Footer>
        </Modal>
        
      )}

{typeof addVmConnectionsPopupOpen === 'boolean' && (
     

        <Modal
          show={addVmConnectionsPopupOpen}
          onHide={onAddVmConnectionsPopupToggle}
          aria-labelledby="contained-modal-title"
        >
        <Modal.Header closeButton>
            <Modal.Title>Main Terminal list</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <Row >
            <Col sm={8}>
            <label htmlFor='vm-list' className='col-6 col-form-label text-left'>Select Terminal:</label>
            <div className='col-6' style={{ overflowY: 'scroll'}}>

               {availableTerminals.map((terminal, key) => {
                    let checked = false
                    if(findIndex(selectedTerminals, (o) => { return o.terminalIp === terminal.terminalIp }) !== -1) {
                      checked = true
                    }
                    return (
                      <div key={key} style={{ backgroundColor: checked ? '#e6f2ff' : 'transparent' }}>
                      <input  type='checkbox' id="chk" style={{ verticalAlign:'middle', margin:'0px 4px'  }} checked={checked} value={terminal.terminalIp} onClick={() => { onTerminalSelect(terminal.terminalIp, terminal.terminalName) }} />
                      <label style={{  verticalAlign:'middle'}}>{terminal.terminalName}</label>
                      </div> 
                  )
                })}

            </div>
            </Col>
             <Col sm={4}>
            <div>
            <input type='radio' name='type' value='rdesktop'  onClick ={() => { onTypeSelect('rdesktop') }}/><label style={{  verticalAlign:'middle'}}>Rdesktop </label> 
             <input type='radio' name ='type' value='VNC' onClick ={() => { onTypeSelect('VNC') }}/><label style={{  verticalAlign:'middle' , display:'inline'}}>VNC </label>
             </div>

            </Col>
          </Row>
        
          </Modal.Body>
          <Modal.Footer>
              <button type='submit' className='btn btn-primary' onClick={addTerminalToSelectedVm}>Submit</button>
                  
          </Modal.Footer>
        </Modal>
        )} 
        </div>   
)
}
export default Vm
