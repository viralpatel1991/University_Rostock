import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import {vmAdd,vmRemove,vmFetch,loadVmDetails,updateVmDetails,terminalFetch, addTerminalToConnection,removeConnectedTerminal, addVmToConnection} from '../modules/vm'
import Vm from '../components/Vm'
import findIndex from 'lodash/findIndex'

const mapDispatchToProps = {
  vmAdd,
  vmRemove,
  vmFetch,
  loadVmDetails,
  updateVmDetails,
  terminalFetch,
  addTerminalToConnection,
  removeConnectedTerminal
}

const mapStateToProps = (state) => ({
  terminals: state.vm.terminals,
  selectedVmData: state.vm.selectedVmData,
  vms: state.vm.vms,
  error: state.vm.error
})

class VmContainer extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      vmName: '',
      vmIp: '',
      error: '',
      selectedVmName: '',
      selectedVmIp: '',
      selectedVmNameChanged: '',
      selectedVmIpChanged: '',
      terminalToSelectedVmAddIp: '',
      addVmPopupOpen: false,
      addVmConnectionsPopupOpen: false,
      availableTerminals: [],
      selectedTerminals: [],
      type: 'rdesktop'
    }

    this.onVmNameChange = this.onVmNameChange.bind(this)
    this.onVmIpChange = this.onVmIpChange.bind(this)
    this.onVmAdd = this.onVmAdd.bind(this)
    this.onVmRemove = this.onVmRemove.bind(this)
    this.onVmDetails = this.onVmDetails.bind(this)
    this.onSelectedVmUpdateName = this.onSelectedVmUpdateName.bind(this)
    this.onSelectedVmUpdateIp = this.onSelectedVmUpdateIp.bind(this)
    this.onSelectedVmUpdate = this.onSelectedVmUpdate.bind(this)
    this.onAddVmPopupToggle = this.onAddVmPopupToggle.bind(this)
    this.onAddVmConnectionsPopupToggle = this.onAddVmConnectionsPopupToggle.bind(this)
    this.addTerminalToSelectedVm = this.addTerminalToSelectedVm.bind(this)
    this.onConnectedTerminalRemove = this.onConnectedTerminalRemove.bind(this)
    this.onTerminalToSelectedVmChange = this.onTerminalToSelectedVmChange.bind(this)
    this.onTerminalSelect = this.onTerminalSelect.bind(this)
    this.onTypeSelect = this.onTypeSelect.bind(this)

  }

  componentWillMount() {
    if (!localStorage.getItem('key')) {
      this.context.router.push('/')
    }
    this.props.vmFetch()
  }

   onTerminalSelect (terminalIp, terminalName) {
    const index = findIndex(this.state.selectedTerminals, (o) => { return o.terminalIp === terminalIp })
    if(index === -1) {
      const newState = this.state.selectedTerminals
      newState.push({ terminalIp: terminalIp, terminalName:terminalName })
      this.setState({ selectedTerminals: newState })
    } else {
      const newState = this.state.selectedTerminals
      newState.splice(index, 1)
      this.setState({ selectedTerminals: newState })
    }
    console.log( this.state.selectedTerminals.terminalIp)
  }

  onTypeSelect(type){
     this.setState({ type: type })
  }

  onSelectedVmUpdateName (e) {
    this.setState({ selectedVmNameChanged: e.target.value })
  }

  onSelectedVmUpdateIp (e) {
    this.setState({ selectedVmIpChanged: e.target.value })
  }

  onVmNameChange (e) {
    this.setState({ vmName: e.target.value })
  }

  onVmIpChange (e) {
    this.setState({ vmIp: e.target.value })
  }

  validateIpAddress (ipaddress) {
    const ipFormat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
    return ipaddress.match(ipFormat)
  }

  onVmAdd () {
    if(this.state.vmName < 1 || !this.validateIpAddress(this.state.vmIp) || !/[a-z]/i.test(this.state.vmName)) {
      this.setState({ error: 'Invalid input data' })
    } else {
      this.props.vmAdd(this.state.vmName, this.state.vmIp)
      this.setState({ vmIp: '', vmName: '', error: '', addVmPopupOpen: false })
    }
  }

  onVmRemove (data) {
    const confirmation = confirm('Are you sure, you want to delete vm?')
    if(confirmation) {
      this.props.vmRemove(data.vmName, data.vmIp)
      this.setState({selectedVmName:''})
    }
  }

  onVmDetails (data) {
    this.setState({ selectedVmName: data.vmName, selectedVmIp: data.vmIp })
    this.props.loadVmDetails(data.vmName, data.vmIp)
    setTimeout(() => {
      this.props.terminalFetch()
    }, 200)
  }

  onSelectedVmUpdate () {
    const { selectedVmIp, selectedVmName, selectedVmNameChanged, selectedVmIpChanged } = this.state


    if (selectedVmNameChanged || selectedVmIpChanged) {
      if (selectedVmNameChanged && selectedVmIpChanged) {
         if(selectedVmNameChanged < 1 || !this.validateIpAddress(selectedVmIpChanged) || !/[a-z]/i.test(selectedVmNameChanged)){ 
              this.setState({ error: 'Invalid input data' })}
          else{
        this.props.updateVmDetails(selectedVmIp, selectedVmName, selectedVmNameChanged, selectedVmIpChanged)
        this.setState({ selectedVmName: this.state.selectedVmNameChanged, selectedVmIp: this.state.selectedVmIpChanged, selectedVmNameChanged: '', selectedVmIpChanged: '',error: '' })
        setTimeout(() => {
          this.props.loadVmDetails(selectedVmNameChanged, selectedVmIpChanged)
        }, 200)
      }
    }
       else if (selectedVmNameChanged) {
        if(selectedVmNameChanged < 1  || !/[a-z]/i.test(selectedVmNameChanged)){ 
              this.setState({ error: 'Invalid input data' })}
          else{
     this.props.updateVmDetails(selectedVmIp, selectedVmName, selectedVmNameChanged, selectedVmIpChanged)
     this.setState({ selectedVmName: this.state.selectedVmNameChanged, selectedVmNameChanged: '', selectedVmIpChanged: '',error: '' })
        setTimeout(() => {
          this.props.loadVmDetails(selectedVmNameChanged, selectedVmIp)
        }, 200)
      }
    }
       else if (selectedVmIpChanged) {
        if(!this.validateIpAddress(selectedVmIpChanged)){ 
              this.setState({ error: 'Invalid input data' })}
          else{
        this.props.updateVmDetails(selectedVmIp, selectedVmName, selectedVmNameChanged, selectedVmIpChanged)
        this.setState({ selectedVmIp: this.state.selectedVmIpChanged, selectedVmNameChanged: '', selectedVmIpChanged: '',error: '' })
        setTimeout(() => {
          this.props.loadVmDetails(selectedVmName, selectedVmIpChanged)
        }, 200)
      }
    }
      setTimeout(() => {
        this.props.terminalFetch()
      }, 200)
    }
  }

  onAddVmPopupToggle () {
    this.setState({ addVmPopupOpen: !this.state.addVmPopupOpen })
  }

  onAddVmConnectionsPopupToggle () {
    const availableTerminals = this.props.terminals.reduce((acc, element) => {

      if(this.props.selectedVmData.length === 0) {
        acc.push(element)
      } else {
        let passed = true
        const isAlreadyConnected = this.props.selectedVmData.map((data) => {
          if (data.terminalData.terminalIp === element.terminalIp && data.terminalData.terminalName === element.terminalName) {
            passed = false
          }
        })
        if (passed) {
          acc.push(element)
        }
      }
      return acc;
    }, [])
    this.setState({ availableTerminals: availableTerminals, addVmConnectionsPopupOpen: !this.state.addVmConnectionsPopupOpen })
  }

 addTerminalToSelectedVm () {
    const { terminalToSelectedVmAddIp, terminalToSelectedVmAddName,selectedVmName, selectedVmIp, type } = this.state
     console.log( terminalToSelectedVmAddIp, terminalToSelectedVmAddName,selectedVmName, selectedVmIp  + 'Vmlist')
    if ( terminalToSelectedVmAddIp, terminalToSelectedVmAddName,selectedVmName && selectedVmIp) {
      this.state.selectedTerminals.map( (o) => {
      console.log( o.terminalIp + o.terminalName)
        this.props.addTerminalToConnection( o.terminalIp, o.terminalName, selectedVmName, selectedVmIp, type)
      })
      setTimeout(() => {
        this.props.loadVmDetails(selectedVmName, selectedVmIp)
      }, 200)
      this.setState({ addVmConnectionsPopupOpen: false, selectedTerminals:[], terminalToSelectedVmAddIp:'',terminalToSelectedVmAddName:'', type: 'rdesktop' })
    }
  }

  onTerminalToSelectedVmChange (e) {
    const terminal = this.props.terminals.filter((o) => { return o.terminalIp === e.target.value })
   

    this.setState({ terminalToSelectedVmAddIp: e.target.value, terminalToSelectedVmAddName: terminal[0].terminalName })
  }

  onConnectedTerminalRemove (data) {
    const { selectedVmName, selectedVmIp } = this.state
    if (data.terminalIp && data.terminalName && selectedVmName && selectedVmIp) {
      this.props.removeConnectedTerminal(selectedVmName, selectedVmIp, data.terminalName, data.terminalIp)
      setTimeout(() => {
        this.props.loadVmDetails(selectedVmName, selectedVmIp)
      }, 200)
    }
  }

  render () {
    //console.log(this.props.selectedVmData )
 
    return (
      <Vm
        {...this.props}
        {...this.state}

        onVmNameChange={this.onVmNameChange}
        onVmIpChange={this.onVmIpChange}
        onVmAdd={this.onVmAdd}
        onVmRemove={this.onVmRemove}
        onVmDetails={this.onVmDetails}
        onSelectedVmUpdateName={this.onSelectedVmUpdateName}
        onSelectedVmUpdateIp={this.onSelectedVmUpdateIp}
        onSelectedVmUpdate={this.onSelectedVmUpdate}
        onAddVmPopupToggle={this.onAddVmPopupToggle}
        onAddVmConnectionsPopupToggle={this.onAddVmConnectionsPopupToggle}
        addTerminalToSelectedVm={this.addTerminalToSelectedVm}
        onConnectedTerminalRemove={this.onConnectedTerminalRemove}
        onTerminalToSelectedVmChange={this.onTerminalToSelectedVmChange}
        onTerminalSelect={this.onTerminalSelect}
        onTypeSelect={this.onTypeSelect}
        
      />
    )
  }
}

VmContainer.contextTypes = {
  router: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(VmContainer)
