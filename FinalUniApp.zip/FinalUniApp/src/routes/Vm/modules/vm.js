import findIndex from 'lodash/findIndex'
import remove from 'lodash/remove'
import filter from 'lodash/filter'
import axios from 'axios'

axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

// ------------------------------------
// Constants
// ------------------------------------
export const TERMINAL_FETCH = 'TERMINAL_FETCH'
export const TERMINAL_ERROR = 'TERMINAL_ERROR'
export const VM_FETCH = 'VM_FETCH'
export const VM_ERROR = 'VM_ERROR'
export const VM_DETAILS_FETCH = 'VM_DETAILS_FETCH'
export const VM_DETAILS_FETCH_ERROR = 'VM_DETAILS_FETCH_ERROR'
// ------------------------------------
// Actions
// ------------------------------------
// export function systemAdd (data) {
//   return {
//     type    : SYSTEM_ADD,
//     payload : data
//   }
// }

export const terminalFetch = () => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.get('/api/getData?db=terminals&key=' + localStorage.getItem('key'))
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: TERMINAL_FETCH,
              payload: response.data.params
            })
          } else {
            dispatch({
              type: TERMINAL_ERROR,
              payload: response.data.error
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const loadVmDetails = (vmName, vmIp) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.get('/api/getData?db=connections&key=' + localStorage.getItem('key'))
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: VM_DETAILS_FETCH,
              payload: response.data.params,
              vmData: { vmIp, vmName }
            })
          } else {
            dispatch({
              type: VM_DETAILS_FETCH_ERROR,
              payload: response.data.error
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

/*  This is a thunk, meaning it is a function that immediately
    returns a function for lazy evaluation. It is incredibly useful for
    creating async actions, especially when combined with redux-thunk! */
export const terminalRemove = (terminalName, terminalIp) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/removeTerminal', {
        terminalIp: terminalIp,
        terminalName: terminalName,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: TERMINAL_FETCH,
              payload: JSON.parse(response.data.params)
            })
          } else {
            dispatch({
              type: TERMINAL_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const terminalAdd = (terminalName, terminalIp) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/addTerminal', {
        terminalIp: terminalIp,
        terminalName: terminalName,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: TERMINAL_FETCH,
              payload: JSON.parse(response.data.params)
            })
          } else {
            dispatch({
              type: TERMINAL_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const removeConnectedTerminal = (selectedVmName, selectedVmIp, terminalName, terminalIp) => {
  console.log(selectedVmName, selectedVmIp, terminalName, terminalIp + '-----ddddd')
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/removeConnectedTerminal', {
        selectedVmName, selectedVmIp, terminalName, terminalIp,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: VM_FETCH,
              payload: response.data.params
            })
          } else {
            dispatch({
              type: VM_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const updateVmDetails = (selectedVmIp, selectedVmName, selectedVmNameChanged, selectedVmIpChanged) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/changeVm', {
        selectedVmIp,
        selectedVmName,
        selectedVmNameChanged,
        selectedVmIpChanged,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: VM_FETCH,
              payload: JSON.parse(response.data.params)
            })
          } else {
            dispatch({
              type: VM_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const addTerminalToConnection = (terminalToSelectedVmAddIp, terminalToSelectedVmAddName, selectedVmName, selectedVmIp, type) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/addTerminalToConnection', {
        terminalToSelectedVmAddIp, terminalToSelectedVmAddName, selectedVmName, selectedVmIp,type,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: VM_FETCH,
              payload: response.data.params
            })
          } else {
            dispatch({
              type: VM_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const vmRemove = (vmName, vmIp) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/removeVm', {
        vmIp: vmIp,
        vmName: vmName,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: VM_FETCH,
              payload: JSON.parse(response.data.params)
            })
          } else {
            dispatch({
              type: VM_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const vmAdd = (vmName, vmIp) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/addVm', {
        vmIp: vmIp,
        vmName: vmName,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: VM_FETCH,
              payload: JSON.parse(response.data.params)
            })
          } else {
            dispatch({
              type: VM_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const vmFetch = () => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.get('/api/getData?db=vms&key=' + localStorage.getItem('key'))
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: VM_FETCH,
              payload: response.data.params
            })
          } else {
            dispatch({
              type: VM_ERROR,
              payload: response.data.error
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const actions = {
  vmAdd,
  vmRemove,
  vmFetch,
  loadVmDetails,
  updateVmDetails,
  terminalFetch,
  removeConnectedTerminal
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [TERMINAL_FETCH]: (state, action) => {
    const terminals = action.payload
    return Object.assign({}, state, {
      terminals: terminals
    })
  },
  [VM_FETCH]: (state, action) => {
    const vms = action.payload
    return Object.assign({}, state, {
      vms: vms
    })
  },
  [TERMINAL_ERROR]: (state, action) => {
    const { error } = action.payload
    return Object.assign({}, state, {
      error
    })
  },
  [VM_ERROR]: (state, action) => {
    const { error } = action.payload
    return Object.assign({}, state, {
      error
    })
  },
  [VM_DETAILS_FETCH]: (state, action) => {
    const connections = action.payload

    const someData = connections.reduce((acc, element, index) => {
      //console.log(element.vms, action.vmData)
      if (findIndex(element.vms, (o) => { return o.vmName === action.vmData.vmName && o.vmIp === action.vmData.vmIp }) !== -1) {
        acc.push(element)
      }
      return acc;
    }, [])

    return Object.assign({}, state, {
      selectedVmData: someData
    })
  },
}

// ------------------------------------
// Reducer
// ------------------------------------
const initialState = {
  terminals: [],
  vms: [],
  selectedVmData: [],
  error: null
}

export default function counterReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}
