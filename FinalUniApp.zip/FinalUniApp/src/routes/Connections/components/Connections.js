import React from 'react'
import PropTypes from 'prop-types'
import { Col, Grid , Row} from 'react-bootstrap'

import './Connections.scss'

export const Connections = ({
  connectionsList
}) => (
<div>
<Row className="show-grid" style={{ border: '1px solid #a6a6a6', height: '30px' , margin:'30px', marginBottom:'0px'}}>
 <Col  md={12} style={{textAlign:'center',fontWeight:'bold' }}>Show table of connection data</Col>
</Row>
<Row className="show-grid" style={{  border: '1px solid #a6a6a6', height: '320px' , margin:'30px', marginTop:'0px', overflowY: 'scroll' }}>
{connectionsList && connectionsList.map((connection, key) => (
          <div key={key}>
           <div  className='row' style={{ marginTop:'15px', marginRight:'0px', marginLeft:'0px'}}>
              <div className='col-md-6' style={{ borderRight: '1px solid #a6a6a6',textAlign: 'center', backgroundColor:'#6699ff' }}><strong>{connection.terminalData.terminalName}</strong></div>
              <div className='col-md-6' style={{ textAlign: 'center' , backgroundColor:'#6699ff'}}><strong>{connection.terminalData.terminalIp}</strong></div>
            
{connection.vms.map((vm, key) => (
                <div   key={key} className='row' style={{border: '1px solid #a6a6a6' , paddingTop:'2px', paddingBottom:'2px', backgroundColor:'#f2f4f7'}}>
                    <div className='col-md-6' style={{ borderRight: '1px solid #eee',textAlign: 'center' }}>{vm.vmName}</div>
                    <div className='col-md-6' style={{ textAlign: 'center' }}>{vm.vmIp}</div>
                  </div>
              ))}
            </div>
            </div>

        ))}

</Row>
</div>

 
)

Connections.propTypes = {
  connectionsList: PropTypes.array.isRequired
}

export default Connections
