import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { connectionFetch , changeKey, keyFetch} from '../modules/connections'
import Connections from '../components/Connections'

const mapDispatchToProps = {
  connectionFetch,
  changeKey,
  keyFetch
}

const mapStateToProps = (state) => ({
  connectionsList: state.connections.connectionsList
})

class ConnectionsContainer extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      keyInterval : setInterval(() => { this.makeid()}, 60000),
      interval:  setInterval(() => { this.props.connectionFetch()}, 2000),
      interval1:  setInterval(() => { this.props.keyFetch()}, 2000)
    }
  }

  makeid() {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    console.log('makeid')
    for (var i = 0; i < 10; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    this.props.changeKey(text);
  }

  componentWillMount() {
    if (!localStorage.getItem('key')) {
      this.context.router.push('/')
    }
    this.props.connectionFetch()
  }

  componentWillUnmount() {
    clearInterval(this.state.interval)
    clearInterval(this.state.keyInterval)
    clearInterval(this.state.interval1)
  }

  render () {
    
    const { connectionsList } = this.props
    console.log(connectionsList)
    return (
      <Connections
        connectionsList={connectionsList}
      />
    )
  }
}

ConnectionsContainer.contextTypes = {
  router: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(ConnectionsContainer)
