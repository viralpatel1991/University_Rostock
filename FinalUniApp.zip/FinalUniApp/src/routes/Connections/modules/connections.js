import findIndex from 'lodash/findIndex'
import remove from 'lodash/remove'
import axios from 'axios'

axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

// ------------------------------------
// Constants
// ------------------------------------
export const CONNECTIONS_FETCH = 'CONNECTIONS_FETCH'
export const CONNECTION_ERROR = 'CONNECTION_ERROR'
export const KEY_FETCH = 'KEY_FETCH'

// ------------------------------------
// Actions
// ------------------------------------
// export function systemAdd (data) {
//   return {
//     type    : SYSTEM_ADD,
//     payload : data
//   }
// }

export const connectionFetch = () => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.get('/api/getData?db=connections&key=' + localStorage.getItem('key'))
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: CONNECTIONS_FETCH,
              payload: response.data.params
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const keyFetch = () => {
   return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.get('/api/getkey')
        .then((response) => {
          if(!response.data.error) {
            

            dispatch({
              type: KEY_FETCH,
              payload: response.data.params
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const changeKey = (key) => {
  console.log(key)
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/changeKey', {
        key: key
      })
      
         .then((response) => {
          if(!response.data.error) {
            localStorage.setItem('key', key);

            dispatch({
              type: KEY_FETCH,
              payload: response.data.params
            })
          } 
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

/*  This is a thunk, meaning it is a function that immediately
    returns a function for lazy evaluation. It is incredibly useful for
    creating async actions, especially when combined with redux-thunk! */

export const actions = {
  connectionFetch,
  changeKey,
  keyFetch
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [CONNECTIONS_FETCH]: (state, action) => {
    const connectionsList = action.payload
    return Object.assign({}, state, {
      connectionsList: connectionsList
    })
  },
  [CONNECTION_ERROR]: (state, action) => {
    const { error } = action.payload
    return Object.assign({}, state, {
      error
    })
  },
  [KEY_FETCH]: (state, action) => {
    const key = action.payload
    return Object.assign({}, state, {
      key: key
    })
  }
}

// ------------------------------------
// Reducer
// ------------------------------------
const initialState = {
  connectionsList: [],
  error: null,
  key : null
}

export default function counterReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}
