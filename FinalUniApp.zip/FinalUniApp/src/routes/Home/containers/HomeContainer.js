import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { login, logout } from '../modules/home'
import HomeView from '../components/HomeView'

const mapDispatchToProps = {
  login,
  logout
}

const mapStateToProps = (state) => ({
  error: state.home.error,
  authKey: state.home.key
})

class HomeContainer extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      login: '',
      password: '',
      error: ''
    }

    this.onLogin = this.onLogin.bind(this)
    this.onLogout = this.onLogout.bind(this)
    this.onPasswordChange = this.onPasswordChange.bind(this)
    this.onLoginChange = this.onLoginChange.bind(this)
  }

  componentWillMount() {
    //this.props.systemFetch()
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.authKey) {
      localStorage.setItem('key', nextProps.authKey)
    }
  }

  onLogin () {
    const { login, password } = this.state
    if (login && password) {
      this.props.login(login, password)
      this.setState({ login: '', password: '' })
    } else {
      this.setState({ error: 'Login and password cannot be empty' })
    }
  }

  onLogout () {
    this.props.logout()
  }

  onPasswordChange (e) {
    this.setState({ password: e.target.value })
  }

  onLoginChange (e) {
    this.setState({ login: e.target.value })
  }

  render () {
    console.log(this)
    return (
      <HomeView
        onPasswordChange={this.onPasswordChange}
        onLoginChange={this.onLoginChange}
        onLogin={this.onLogin}
        error={this.state.error}
        loginError={this.props.error}
        authKey={this.props.authKey}
        onLogout={this.onLogout}
      />
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(HomeContainer)
