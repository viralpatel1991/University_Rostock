
import findIndex from 'lodash/findIndex'
import remove from 'lodash/remove'
import axios from 'axios'

axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

// ------------------------------------
// Constants
// ------------------------------------
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS'
export const LOGIN_FAILED = 'LOGIN_FAILED'
export const LOGOUT = 'LOGOUT'

// ------------------------------------
// Actions
// ------------------------------------
// export function systemAdd (data) {
//   return {
//     type    : SYSTEM_ADD,
//     payload : data
//   }
// }

export const login = (login, password) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/login', {
        login, password
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: LOGIN_SUCCESS,
              payload: response.data.params
            })
          } else {
            dispatch({
              type: LOGIN_FAILED,
              payload: response.data.error
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export function logout (data) {
  return {
    type: LOGOUT
  }
}

export const actions = {
  login,
  logout
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [LOGIN_SUCCESS]: (state, action) => {
    const key = action.payload
    return Object.assign({}, state, {
      error: false,
      key: key
    })
  },
  [LOGOUT]: (state, action) => {
    localStorage.removeItem('key')
    return Object.assign({}, state, {
      error: false,
      key: false
    })
  },
  // [SYSTEM_REMOVE]: (state, action) => {
  //   const systemIp = action.payload
  //   const indexToRemove = findIndex(state.systems, (system) => { return system.systemIp === systemIp })
  //   if (indexToRemove !== -1) {
  //     state.systems.splice(indexToRemove, 1)
  //   }
  //   return Object.assign({}, state, {
  //     systems: [...state.systems]
  //   })
  // },
  [LOGIN_FAILED]: (state, action) => {
    const { error } = action.payload
    return Object.assign({}, state, {
      error
    })
  },
}

// ------------------------------------
// Reducer
// ------------------------------------
const initialState = {
  error: null,
  key: null
}

export default function homeReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}
