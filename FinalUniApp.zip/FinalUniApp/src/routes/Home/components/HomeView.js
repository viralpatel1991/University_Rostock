import React from 'react'
import PropTypes from 'prop-types'
import './HomeView.scss'

export const HomeView = ({
  onLoginChange, onPasswordChange,
  onLogin, login, password, error,
  authKey, onLogout
}) => (
  <div id="outPopUp">
    {!localStorage.getItem('key')
        ?
        <div>
            <h4 style={{ marginTop: '10px', textAlign: 'center'}}>Log in</h4>

            
              <label className='form-label text-left'>User Name:</label>
                <input className='form-control' type='text' id='login' onChange={onLoginChange} value={login} />

              <label className='form-label text-left'>Password:</label>
                <input className='form-control' type='password' id='password' onChange={onPasswordChange} value={password} />

              <div className='text-right'id='btnStyle' style={{height: '10px',  textAlign: 'right' , color: 'red'}}>
                {error && (
                  error
                )}
                <button  type='submit' className='btn btn-primary'style={{marginLeft: '20%'}} onClick={onLogin}>Submit</button>

              </div>
          </div>

        :
          <button type='submit' style={{marginLeft: '40%'}} className='btn btn-primary text-center' onClick={onLogout}>Log out</button>
      }
  </div>
)

export default HomeView
