import React from 'react'
import PropTypes from 'prop-types'
import './Terminal.scss'
import findIndex from 'lodash/findIndex'
import { Col, Grid , Row, Panel, Form, FormGroup,FormControl,ControlLabel,Button,Modal} from 'react-bootstrap'

import Popup from 'components/Popup'

export const Terminal = ({
  terminals, onTerminalAdd, onTerminalRemove,
  onTerminalNameChange, onTerminalIpChange,
  terminalName, terminalIp, error,
  onTerminalDetails, selectedTerminalData,
  selectedTerminalName, selectedTerminalIp,
  onSelectedTerminalUpdateIp, onSelectedTerminalUpdateName,
  onSelectedTerminalUpdate,
  addTerminalPopupOpen, addTerminalConnectionsPopupOpen,
  onAddTerminalPopupToggle, onAddTerminalConnectionsPopupToggle,
  availableVms, addVmToSelectedTerminal,
  onVmToSelectedTerminalChange, onConnectedVmRemove,
  vmToSelectedTerminalAddIp, selectedTerminalIpChanged,
  selectedTerminalNameChanged, onVMSelect, selectedVMs, onTypeSelect
}) => (

  <div>
    <Row style={{margin:'10px 30px'}}>
      <Col md={6}  style={{height: '400px'}}>
        <Row style={{border: '1px solid #eee',height: '360px', overflowY: 'scroll', paddingLeft:'1em',paddingRight:'1em'}} >
          {terminals && terminals.map((terminal, key) => (
            <Panel  key={key} style={{  textAlign: 'left'}}  value={terminal.terminalIp} >
              <label style={{  verticalAlign:'middle', paddingTop:'5px', width:'80%'}} onClick={() => {onTerminalDetails({ terminalName: terminal.terminalName, terminalIp: terminal.terminalIp })}}>{terminal.terminalName}</label>
              <button className='Btn' value={terminal.terminalIp} onClick={() => {onTerminalRemove({ terminalName: terminal.terminalName, terminalIp: terminal.terminalIp })}}>
                &#215;
              </button>
            </Panel>
          ))}
        </Row>
        <Row style={{ border: '1px solid #eee',height: '40px'}}>
          <button type='submit' className='btn btn-primary' onClick={onAddTerminalPopupToggle}>Add Terminal</button>
        </Row>
      </Col>

      <Col md={6} style={{height: '400px'}}>
        {selectedTerminalName && (
          <Row style={{ border: '1px solid #eee',paddingTop: '5px', verticalAlign:'middle',height: '30px', textAlign:'center'}} >
            <strong>Detail of {selectedTerminalName}</strong>
          </Row>
        )}

        {selectedTerminalName && (
          <Row style={{border: '1px solid #eee', paddingTop:'5px'}} >
            <Col  md={5}>
              <Row style={{height: '35px'}}>
                <label>Terminal Name : {selectedTerminalName} </label>
              </Row>
              <Row style={{ height: '35px'}}>
                <label>Terminal Ip : {selectedTerminalIp }</label>
              </Row>
              <Row style={{ color: 'red'}}>
                {error && (
                  error
                )}
              </Row>
            </Col>
            <Col  md={5} >
              <Row style={{height: '35px'}}>
                <input style={{ padding: '.25rem'}} className='form-control' type='text' id='terminal-name' name='terminalName' placeholder='update name' onChange={onSelectedTerminalUpdateName} value={selectedTerminalNameChanged} />
              </Row>
              <Row style={{ height: '35px'}}>
                <input style={{ padding: '.25rem'}} className='form-control' type='text' id='terminal-ip' name='terminalIp' placeholder='update IP' onChange={onSelectedTerminalUpdateIp} value={selectedTerminalIpChanged} />
              </Row>
            </Col>
            <Col  md={2} >
              <Row style={{ verticalAlign:'middle', paddingTop:'10px'}}>
                <button type='submit' className='btn btn-primary center-block' onClick={onSelectedTerminalUpdate}>Submit</button>
              </Row>
            </Col>
          </Row>
        )}

       {selectedTerminalName && (
        <Row style={{ border: '1px solid #eee'}}>
          <Row style={{ verticalAlign:'middle', paddingTop:'5px', height: '40px',textAlign:'center'}} >
            <strong>List of connected Virtual Machine with {selectedTerminalName}</strong>
          </Row>
          <Row style={{ marginLeft: '0px', marginRight:'0px'}}>
            <Col md={8} style={{ border: '1px solid #eee',height: '250px', overflowY: 'scroll'}}>
              {selectedTerminalData && selectedTerminalData.map((connection, key) => (
                <div key={key}>
                  {connection.vms.map((vm, key) => (
                    <Panel key={key} style={{  textAlign: 'left'}}>
                      <label style={{  verticalAlign:'middle', paddingTop:'5px'}}>{vm.vmName}</label>
                      <button className='Btn' value={vm.vmIp} onClick={() => {onConnectedVmRemove({ vmName: vm.vmName, vmIp: vm.vmIp })}}>
                         &#215;
                      </button>
                    </Panel>
                  ))}
                </div>
              ))}
            </Col>
            <Col md={4}   style={{ border: '1px solid #eee',height: '250px', paddingTop:'50px',textAlign:'center'}}>
              <button className='btn btn-primary' style={{ marginTop: '10px' }} onClick={onAddTerminalConnectionsPopupToggle}>Add VM</button>
           
            </Col>
          </Row>
      </Row>
      )}
    </Col>
  </Row>
  
{typeof addTerminalPopupOpen === 'boolean' && (

  <div className="modal-container">
        <Modal
          show={addTerminalPopupOpen}
          onHide={onAddTerminalPopupToggle}
          aria-labelledby="contained-modal-title"
        >
          <Modal.Header closeButton>
            <Modal.Title>Create Terminal</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <Row >
            <Col sm={8}>
            <label className='form-label text-left'>Terminal Name:</label>
            <input className='form-control text-left'  type='text' id='terminal-name' name='terminalName' onChange={onTerminalNameChange} value={terminalName} />
            </Col>
            <Col sm={8}>
            <label>Terminal Ip:</label>
            <input className='form-control' type='text' id='terminal-ip' name='terminalIp' onChange={onTerminalIpChange} value={terminalIp} />
            </Col>
            </Row>

          </Modal.Body>
          <Modal.Footer>
            <Row>
            <Col sm={9}>
            <div className='text-left' style={{ color: 'red'}}>
              {error && (
                error
              )}
              </div>
            </Col>
            <Col sm={3} >
               <Button  className='btn btn-primary' onClick={onTerminalAdd}>Submit</Button>
            </Col>
            </Row>

           
          </Modal.Footer>
        </Modal>
      </div>
        
      )}

      {typeof addTerminalConnectionsPopupOpen === 'boolean' && (
     

        <Modal
          show={addTerminalConnectionsPopupOpen}
          onHide={onAddTerminalConnectionsPopupToggle}
          aria-labelledby="contained-modal-title"
        >
        <Modal.Header closeButton>
            <Modal.Title>Main VM list</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <Row >
            <Col sm={8}>
            <label htmlFor='vm-list' className='col-6 col-form-label text-left'>Select Vm:</label>
            <div className='col-6' style={{ overflowY: 'scroll'}}>

               {availableVms.map((vm, key) => {
                    let checked = false
                    if(findIndex(selectedVMs, (o) => { return o.vmIp === vm.vmIp }) !== -1) {
                      checked = true
                    }
                    return (
                      <div key={key} style={{ backgroundColor: checked ? '#e6f2ff' : 'transparent' }}>
                      <input  type='checkbox' id="chk" style={{ verticalAlign:'middle', margin:'0px 4px'  }} checked={checked} value={vm.vmIp} onClick={() => { onVMSelect(vm.vmIp, vm.vmName, 'rdesktop') }} />
                      <label style={{  verticalAlign:'middle'}}>{vm.vmName}</label>
                      </div> 
                  )
                })}

            </div>
            </Col>
            <Col sm={4}>
            <div>
            <input type='radio' name='type' value='rdesktop'  onClick ={() => { onTypeSelect('rdesktop') }}/><label style={{  verticalAlign:'middle'}}>Rdesktop </label> 
             <input type='radio' name ='type' value='VNC' onClick ={() => { onTypeSelect('VNC') }}/><label style={{  verticalAlign:'middle' , display:'inline'}}>VNC </label>
             </div>

            </Col>
          </Row>
        
          </Modal.Body>
          <Modal.Footer>
              <button type='submit' className='btn btn-primary' onClick={addVmToSelectedTerminal}>Submit</button>
                  
          </Modal.Footer>
        </Modal>
      )}
  </div>

)

Terminal.propTypes = {
  terminals: PropTypes.array.isRequired,
  onTerminalAdd: PropTypes.func.isRequired,
  onTerminalRemove: PropTypes.func.isRequired,
}

export default Terminal
