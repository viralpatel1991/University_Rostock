import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { terminalAdd, terminalRemove, terminalFetch, loadTerminalDetails, updateTerminalDetails, vmFetch, addVmToConnection, removeConnectedVm } from '../modules/terminal'
import Terminal from '../components/Terminal'
import findIndex from 'lodash/findIndex'

const mapDispatchToProps = {
  terminalAdd,
  terminalRemove, 
  terminalFetch,
  loadTerminalDetails, 
  updateTerminalDetails, 
  vmFetch, 
  addVmToConnection,
  removeConnectedVm
}

const mapStateToProps = (state) => ({
  terminals: state.terminal.terminals,
  selectedTerminalData: state.terminal.selectedTerminalData,
  vms: state.terminal.vms,
  error: state.terminal.error
})

class TerminalContainer extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      terminalName: '',
      terminalIp: '',
      error: '',
      selectedTerminalName: '',
      selectedTerminalIp: '',
      selectedTerminalNameChanged: '',
      selectedTerminalIpChanged: '',
      addTerminalPopupOpen: false,
      addTerminalConnectionsPopupOpen: false,
      availableVms: [],
      selectedVMs: [],
      type:'rdesktop'
    }

    this.onTerminalNameChange = this.onTerminalNameChange.bind(this)
    this.onTerminalIpChange = this.onTerminalIpChange.bind(this)
    this.onTerminalAdd = this.onTerminalAdd.bind(this)
    this.onTerminalRemove = this.onTerminalRemove.bind(this)
    this.onTerminalDetails = this.onTerminalDetails.bind(this)
    this.onSelectedTerminalUpdateName = this.onSelectedTerminalUpdateName.bind(this)
    this.onSelectedTerminalUpdateIp = this.onSelectedTerminalUpdateIp.bind(this)
    this.onSelectedTerminalUpdate = this.onSelectedTerminalUpdate.bind(this)
    this.onAddTerminalPopupToggle = this.onAddTerminalPopupToggle.bind(this)
    this.onAddTerminalConnectionsPopupToggle = this.onAddTerminalConnectionsPopupToggle.bind(this)
    this.addVmToSelectedTerminal = this.addVmToSelectedTerminal.bind(this)
    //this.onVmToSelectedTerminalChange = this.onVmToSelectedTerminalChange.bind(this)
    this.onConnectedVmRemove = this.onConnectedVmRemove.bind(this)
    this.onVMSelect = this.onVMSelect.bind(this)
    this.onTypeSelect = this.onTypeSelect.bind(this)
    
  }

  onVMSelect (vmIp, vmName, type) {
    const index = findIndex(this.state.selectedVMs, (o) => { return o.vmIp === vmIp })
    if(index === -1) {
      const newState = this.state.selectedVMs
      newState.push({ vmIp, vmName, type })
      this.setState({ selectedVMs: newState })
    } else {
      const newState = this.state.selectedVMs
      newState.splice(index, 1)
      this.setState({ selectedVMs: newState })
    }
    console.log(this.state.selectedVMs.length)
  }

  onTypeSelect(type){
     this.setState({ type: type })
  }

  componentWillMount() {
    if (!localStorage.getItem('key')) {
      this.context.router.push('/')
    }
    this.props.terminalFetch()
  }

  onSelectedTerminalUpdateName (e) {
    this.setState({ selectedTerminalNameChanged: e.target.value })
  }

  onSelectedTerminalUpdateIp (e) {
    this.setState({ selectedTerminalIpChanged: e.target.value })
  }

  onTerminalNameChange (e) {
    this.setState({ terminalName: e.target.value })
  }

  onTerminalIpChange (e) {
    this.setState({ terminalIp: e.target.value })
  }

  validateIpAddress (ipaddress) {
    const ipFormat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
    return ipaddress.match(ipFormat)
  }

  onTerminalAdd () {
    if(this.state.terminalName < 1 || !this.validateIpAddress(this.state.terminalIp) || !/[a-z]/i.test(this.state.terminalName)) {
      this.setState({ error: 'Invalid input data' })
    } else {
      this.props.terminalAdd(this.state.terminalName, this.state.terminalIp)
      this.setState({ terminalIp: '', terminalName: '', error: '', addTerminalPopupOpen: false })
    }
  }

  onTerminalRemove (data) {
   
    const confirmation = confirm('Are you sure, you want to delete Terminal?')
    if(confirmation) {
      this.props.terminalRemove(data.terminalName, data.terminalIp)
      this.setState({ selectedTerminalName: ''})
    }

  }

  onTerminalDetails (data) {
    this.setState({ selectedTerminalName: data.terminalName, selectedTerminalIp: data.terminalIp })
    this.props.loadTerminalDetails(data.terminalName, data.terminalIp)
    setTimeout(() => {
      this.props.vmFetch()
    }, 200)
  }

  onSelectedTerminalUpdate () {
    const { selectedTerminalIp, selectedTerminalName, selectedTerminalNameChanged, selectedTerminalIpChanged } = this.state

 

        if (selectedTerminalNameChanged && selectedTerminalIpChanged) {
          if(selectedTerminalNameChanged < 1 || !this.validateIpAddress(selectedTerminalIpChanged) || !/[a-z]/i.test(selectedTerminalNameChanged)){ 
              this.setState({ error: 'Invalid input data' })}
          else{
            this.props.updateTerminalDetails(selectedTerminalIp, selectedTerminalName, selectedTerminalNameChanged, selectedTerminalIpChanged)
            this.setState({ selectedTerminalName: this.state.selectedTerminalNameChanged, selectedTerminalIp: this.state.selectedTerminalIpChanged, selectedTerminalNameChanged: '', selectedTerminalIpChanged: '', error: '' })
            setTimeout(() => {
              this.props.loadTerminalDetails(selectedTerminalNameChanged, selectedTerminalIpChanged)
            }, 200)
          }
        }

  
         else if (selectedTerminalNameChanged) {
  
              if(selectedTerminalNameChanged < 1 ||  !/[a-z]/i.test(selectedTerminalNameChanged)){ 
              this.setState({ error: 'Invalid input data' }) 
              }
            else{
              this.props.updateTerminalDetails(selectedTerminalIp, selectedTerminalName, selectedTerminalNameChanged, selectedTerminalIpChanged)
              this.setState({ selectedTerminalName: this.state.selectedTerminalNameChanged, selectedTerminalNameChanged: '', selectedTerminalIpChanged: '', error: '' })
              setTimeout(() => {
                this.props.loadTerminalDetails(selectedTerminalNameChanged, selectedTerminalIp)
              }, 200)
            }
        }
         else if (selectedTerminalIpChanged) {

            if(!this.validateIpAddress(selectedTerminalIpChanged)){ 
              this.setState({ error: 'Invalid input data' })
            }
            else{
              this.props.updateTerminalDetails(selectedTerminalIp, selectedTerminalName, selectedTerminalNameChanged, selectedTerminalIpChanged)
              this.setState({ selectedTerminalIp: this.state.selectedTerminalIpChanged, selectedTerminalNameChanged: '', selectedTerminalIpChanged: '', error: '' })
              setTimeout(() => {
                this.props.loadTerminalDetails(selectedTerminalName, selectedTerminalIpChanged)
              }, 200)
            }
        }

    }



  onAddTerminalPopupToggle () {
    this.setState({ addTerminalPopupOpen: !this.state.addTerminalPopupOpen })
  }

  onAddTerminalConnectionsPopupToggle () {
    const availableVms = this.props.vms.reduce((acc, element) => {
      if(this.props.selectedTerminalData.length === 0) {
        acc.push(element)
        console.log("element" + element.vmName)
      } else {
        const isAlreadyConnected = findIndex(this.props.selectedTerminalData[0].vms, (o) => { return o.vmIp === element.vmIp && o.vmName === element.vmName })
        console.log(isAlreadyConnected)
        if (isAlreadyConnected === -1) {
          acc.push(element);
        }
      }
      return acc;
    }, [])
    this.setState({ availableVms: availableVms, addTerminalConnectionsPopupOpen: !this.state.addTerminalConnectionsPopupOpen })
  }

  addVmToSelectedTerminal () {
   const {selectedVMs, selectedTerminalName, selectedTerminalIp } = this.state
   {selectedVMs.map((array) => {
      this.setState({ selectedVMs: array.type = this.state.type })
    })}
    //console.log( vmToSelectedTerminalAddIp, vmToSelectedTerminalAddName, selectedTerminalName, selectedTerminalIp )
    if (selectedVMs && selectedTerminalName && selectedTerminalIp) {
      this.props.addVmToConnection(selectedVMs, selectedTerminalName, selectedTerminalIp)
      this.setState({ addTerminalConnectionsPopupOpen: false , selectedVMs: [], type:'rdesktop'})
      setTimeout(() => {
        this.props.loadTerminalDetails(selectedTerminalName, selectedTerminalIp)
      }, 200)
    }
  }



 // onVmToSelectedTerminalChange (e) {
  //  const vm = this.props.vms.filter((o) => { return o.vmIp === e.target.value })
  //  console.log("onVmToSelectedTerminalChange" + e.target.value)
  //  this.setState({ vmToSelectedTerminalAddIp: e.target.value, vmToSelectedTerminalAddName: vm[0].vmName })
  //}


  onConnectedVmRemove (data) {
    const { selectedTerminalName, selectedTerminalIp } = this.state

    if (data.vmIp && data.vmName && selectedTerminalName && selectedTerminalIp) {
  
      this.props.removeConnectedVm(selectedTerminalName, selectedTerminalIp, data.vmName, data.vmIp)
      setTimeout(() => {
        this.props.loadTerminalDetails(selectedTerminalName, selectedTerminalIp)
      }, 200)
    }
  }

  render () {
    //console.log(this)
    const { terminals, selectedTerminalData, vms } = this.props
    const {
      terminalName, terminalIp, selectedTerminalIp, selectedTerminalName,
      addTerminalPopupOpen, addTerminalConnectionsPopupOpen,
      availableVms, vmToSelectedTerminalAddIp,
      selectedTerminalNameChanged, selectedTerminalIpChanged, selectedVMs
    } = this.state
    return (
      <Terminal
        terminals={terminals}
        onTerminalNameChange={this.onTerminalNameChange}
        onTerminalIpChange={this.onTerminalIpChange}
        onTerminalAdd={this.onTerminalAdd}
        onTerminalRemove={this.onTerminalRemove}
        terminalName={terminalName}
        terminalIp={terminalIp}
        selectedTerminalIp={selectedTerminalIp}
        selectedTerminalName={selectedTerminalName}
        error={this.state.error}
        onTerminalDetails={this.onTerminalDetails}
        selectedTerminalData={selectedTerminalData}
        onSelectedTerminalUpdate={this.onSelectedTerminalUpdate}
        onSelectedTerminalUpdateIp={this.onSelectedTerminalUpdateIp}
        onSelectedTerminalUpdateName={this.onSelectedTerminalUpdateName}
        addTerminalPopupOpen={addTerminalPopupOpen}
        onAddTerminalPopupToggle={this.onAddTerminalPopupToggle}
        addTerminalConnectionsPopupOpen={addTerminalConnectionsPopupOpen}
        onAddTerminalConnectionsPopupToggle={this.onAddTerminalConnectionsPopupToggle}
        availableVms={availableVms}
        addVmToSelectedTerminal={this.addVmToSelectedTerminal}
        onVmToSelectedTerminalChange={this.onVmToSelectedTerminalChange}
        onConnectedVmRemove={this.onConnectedVmRemove}
        //vmToSelectedTerminalAddIp={vmToSelectedTerminalAddIp}
        selectedTerminalIpChanged={selectedTerminalIpChanged}
        selectedTerminalNameChanged={selectedTerminalNameChanged}
        onVMSelect={this.onVMSelect}
        selectedVMs={selectedVMs}
        onTypeSelect={this.onTypeSelect}
      />
    )
  }
}

TerminalContainer.contextTypes = {
  router: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(TerminalContainer)
