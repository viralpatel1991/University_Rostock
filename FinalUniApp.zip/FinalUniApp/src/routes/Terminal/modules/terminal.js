import findIndex from 'lodash/findIndex'
import remove from 'lodash/remove'
import filter from 'lodash/filter'
import axios from 'axios'

axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

// ------------------------------------
// Constants
// ------------------------------------
export const TERMINAL_FETCH = 'TERMINAL_FETCH'
export const TERMINAL_ERROR = 'TERMINAL_ERROR'
export const VM_FETCH = 'VM_FETCH'
export const VM_ERROR = 'VM_ERROR'
export const TERMINAL_DETAILS_FETCH = 'TERMINAL_DETAILS_FETCH'
export const TERMINAL_DETAILS_FETCH_ERROR = 'TERMINAL_DETAILS_FETCH_ERROR'
// ------------------------------------
// Actions
// ------------------------------------
// export function systemAdd (data) {
//   return {
//     type    : SYSTEM_ADD,
//     payload : data
//   }
// }

export const terminalFetch = () => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.get('/api/getData?db=terminals&key=' + localStorage.getItem('key'))
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: TERMINAL_FETCH,
              payload: response.data.params
            })
          } else {
            dispatch({
              type: TERMINAL_ERROR,
              payload: response.data.error
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const vmFetch = () => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.get('/api/getData?db=vms&key=' + localStorage.getItem('key'))
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: VM_FETCH,
              payload: response.data.params
            })
          } else {
            dispatch({
              type: VM_ERROR,
              payload: response.data.error
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const loadTerminalDetails = (terminalName, terminalIp) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.get('/api/getData?db=connections&key=' + localStorage.getItem('key'))
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: TERMINAL_DETAILS_FETCH,
              payload: response.data.params,
              terminalData: { terminalIp, terminalName }
            })
          } else {
            dispatch({
              type: TERMINAL_DETAILS_FETCH_ERROR,
              payload: response.data.error
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

/*  This is a thunk, meaning it is a function that immediately
    returns a function for lazy evaluation. It is incredibly useful for
    creating async actions, especially when combined with redux-thunk! */
export const terminalRemove = (terminalName, terminalIp) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/removeTerminal', {
        terminalIp: terminalIp,
        terminalName: terminalName,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: TERMINAL_FETCH,
              payload: JSON.parse(response.data.params)
            })
          } else {
            dispatch({
              type: TERMINAL_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const terminalAdd = (terminalName, terminalIp) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/addTerminal', {
        terminalIp: terminalIp,
        terminalName: terminalName,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: TERMINAL_FETCH,
              payload: JSON.parse(response.data.params)
            })
          } else {
            dispatch({
              type: TERMINAL_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const removeConnectedVm = (selectedTerminalName, selectedTerminalIp, vmName, vmIp) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/removeConnectedVm', {
        selectedTerminalName: selectedTerminalName,
        selectedTerminalIp: selectedTerminalIp,
        vmName: vmName,
        vmIp: vmIp,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: TERMINAL_FETCH,
              payload: response.data.params
            })
          } else {
            dispatch({
              type: TERMINAL_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const updateTerminalDetails = (selectedTerminalIp, selectedTerminalName, selectedTerminalNameChanged, selectedTerminalIpChanged) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/changeTerminal', {
        selectedTerminalIp: selectedTerminalIp,
        selectedTerminalName: selectedTerminalName,
        selectedTerminalNameChanged: selectedTerminalNameChanged,
        selectedTerminalIpChanged: selectedTerminalIpChanged,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: TERMINAL_FETCH,
              payload: JSON.parse(response.data.params)
            })
          } else {
            dispatch({
              type: TERMINAL_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const addVmToConnection = (vms, selectedTerminalName, selectedTerminalIp) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/addVmToConnection', {
        vms,
        selectedTerminalName: selectedTerminalName,
        selectedTerminalIp: selectedTerminalIp,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: TERMINAL_FETCH,
              payload: response.data.params
            })
          } else {
            dispatch({
              type: TERMINAL_ERROR,
              payload: response.data.error
            })
          }

          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}



export const actions = {
  terminalAdd,
  terminalRemove,
  terminalFetch,
  loadTerminalDetails,
  updateTerminalDetails,
  vmFetch,
  removeConnectedVm
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [TERMINAL_FETCH]: (state, action) => {
    const terminals = action.payload
    return Object.assign({}, state, {
      terminals: terminals
    })
  },
  [VM_FETCH]: (state, action) => {
    const vms = action.payload
    return Object.assign({}, state, {
      vms: vms
    })
  },
  [TERMINAL_ERROR]: (state, action) => {
    const { error } = action.payload
    return Object.assign({}, state, {
      error
    })
  },
  [VM_ERROR]: (state, action) => {
    const { error } = action.payload
    return Object.assign({}, state, {
      error
    })
  },
  [TERMINAL_DETAILS_FETCH]: (state, action) => {
    const connections = action.payload

    const connectedVms = filter(connections, (o) => {
      //console.log(o.terminalData, action.terminalData)
      return o.terminalData.terminalIp === action.terminalData.terminalIp && o.terminalData.terminalName === action.terminalData.terminalName
    })

    return Object.assign({}, state, {
      selectedTerminalData: connectedVms
    })
  },
}

// ------------------------------------
// Reducer
// ------------------------------------
const initialState = {
  terminals: [],
  vms: [],
  selectedTerminalData: [],
  error: null
}

export default function counterReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}
