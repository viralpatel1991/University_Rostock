import React from 'react'
import PropTypes from 'prop-types'
import findIndex from 'lodash/findIndex'
import './Connection.scss'

export const Connection = ({
  onConnectionAdd, onComputerSelect,
  onSystemSelect, systems, computers, connections,
  selectedSystem, selectedComputers
}) => (
  <div className='row'>
    <div className='col-12'>
      <h5 style={{ margin: '10px 0' }}>Create new connection</h5>
    </div>
    <div className='col-lg-6'>
      <h5>Select system (select only one)</h5>
      <div style={{ border: '1px solid #a6a6a6', overflowX: 'scroll', height: '206px', padding: '20px', textAlign: 'left' }}>
        {systems && systems.map((system, key) => (
          return (
            <div key={key} style={{ border: '1px solid #a6a6a6', marginBottom: '8px', backgroundColor: selectedSystem.systemIp === system.systemIp ? '#a6a6a6' : 'transparent' }}>
              <label className='custom-control custom-checkbox' style={{ paddingBottom: '0', marginBottom: '0', display: 'block' }}>
                <input type='radio' className='custom-control-input' name='system' value={system.systemIp} onClick={() => { onSystemSelect(system.systemIp, system.systemName) }} />
                <span className='custom-control-indicator'></span>
                <span className='custom-control-description'>{system.systemName}</span>
              </label>
            </div>
          )
        ))}
      </div>
    </div>

    <div className='col-lg-6'>
      <h5>Select computers</h5>
      <div style={{ border: '1px solid #a6a6a6', overflowX: 'scroll', height: '206px', padding: '20px', textAlign: 'left' }}>
        {computers && connections && computers.map((computer, key) => {
          let display = true
          const find = connections.map((connection) => {
            return connection.computers.map((item) => {
              if(item.computerIp === computer.computerIp) {
                display = false
              }
            })
          })
          let selected = false
          if(findIndex(selectedComputers, (o) => { return o.computerIp === computer.computerIp }) !== -1) {
            selected = true
          }
          if(display) {
            return (
              <div key={key} style={{ border: '1px solid #a6a6a6', marginBottom: '8px', backgroundColor: selected ? '#a6a6a6' : 'transparent' }}>
                <label className='custom-control custom-checkbox' style={{ paddingBottom: '0', marginBottom: '0', display: 'block' }}>
                  <input type='checkbox' className='custom-control-input' value={computer.computerIp} onClick={() => { onComputerSelect(computer.computerIp, computer.computerName) }} />
                  <span className='custom-control-indicator'></span>
                  <span className='custom-control-description'>{computer.computerName}</span>
                </label>
              </div>
            )
          } else {
            return null
          }
        })}
      </div>
    </div>

    <div className='col-lg-12'>
      <button className='btn btn-primary' onClick={onConnectionAdd} style={{ margin: '20px 0' }}>
        Connect
      </button>
    </div>
  </div>
)

Connection.propTypes = {
  onConnectionAdd: PropTypes.func.isRequired,
}

export default Connection
