import findIndex from 'lodash/findIndex'
import remove from 'lodash/remove'
import axios from 'axios'

axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

// ------------------------------------
// Constants
// ------------------------------------
export const SYSTEM_FETCH = 'SYSTEM_FETCH'
export const COMPUTER_FETCH = 'COMPUTER_FETCH'
export const CONNECTION_FETCH = 'CONNECTION_FETCH'
export const CONNECTION_ERROR = 'CONNECTION_ERROR'

// ------------------------------------
// Actions
// ------------------------------------
// export function systemAdd (data) {
//   return {
//     type    : SYSTEM_ADD,
//     payload : data
//   }
// }

export const systemFetch = () => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.get('/api/getData?db=systems&key=' + localStorage.getItem('key'))
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: SYSTEM_FETCH,
              payload: response.data.params
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const computerFetch = () => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.get('/api/getData?db=computers&key=' + localStorage.getItem('key'))
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: COMPUTER_FETCH,
              payload: response.data.params
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const connectionFetch = () => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.get('/api/getData?db=connections&key=' + localStorage.getItem('key'))
        .then((response) => {
          if(!response.data.error) {
            dispatch({
              type: CONNECTION_FETCH,
              payload: response.data.params
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

/*  This is a thunk, meaning it is a function that immediately
    returns a function for lazy evaluation. It is incredibly useful for
    creating async actions, especially when combined with redux-thunk! */
export const connectionAdd = (systemData, computers) => {
  return (dispatch, getState) => {
    return new Promise((resolve) => {
      axios.post('/api/connectionAdd', {
        systemData,
        computers,
        key: localStorage.getItem('key')
      })
        .then((response) => {
          if(!response.data.error) {
            dispatch(systemFetch)
            dispatch(computerFetch)
          } else {
            dispatch({
              type: CONNECTION_ERROR,
              payload: response.data.error
            })
          }
          resolve()
        })
        .catch((error) => {
          console.log(error)
          resolve()
        })
    })
  }
}

export const actions = {
  connectionAdd,
  systemFetch,
  computerFetch,
  connectionFetch
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [SYSTEM_FETCH]: (state, action) => {
    const systems = action.payload
    return Object.assign({}, state, {
      systems: systems
    })
  },
  [COMPUTER_FETCH]: (state, action) => {
    const computers = action.payload
    return Object.assign({}, state, {
      computers: computers
    })
  },
  [CONNECTION_FETCH]: (state, action) => {
    const connections = action.payload
    return Object.assign({}, state, {
      connections: connections
    })
  },
  [CONNECTION_ERROR]: (state, action) => {
    const { error } = action.payload
    return Object.assign({}, state, {
      error
    })
  },
}

// ------------------------------------
// Reducer
// ------------------------------------
const initialState = {
  systems: [],
  computers: [],
  error: null
}

export default function counterReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}
