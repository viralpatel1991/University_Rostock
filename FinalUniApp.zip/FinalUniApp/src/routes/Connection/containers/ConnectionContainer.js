import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { connectionAdd, systemFetch, computerFetch, connectionFetch } from '../modules/connection'
import Connection from '../components/Connection'
import findIndex from 'lodash/findIndex'

const mapDispatchToProps = {
  connectionAdd,
  systemFetch,
  computerFetch,
  connectionFetch
}

const mapStateToProps = (state) => ({
  connections: state.connection.connections,
  systems: state.connection.systems,
  computers: state.connection.computers,
  error: state.connection.error
})

class ConnectionContainer extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      selectedSystem: { systemName: '', systemIp: '' },
      selectedComputers: []
    }

    this.onSystemSelect = this.onSystemSelect.bind(this)
    this.onComputerSelect = this.onComputerSelect.bind(this)
    this.onConnectionAdd = this.onConnectionAdd.bind(this)
  }

  componentWillMount() {
    if (!localStorage.getItem('key')) {
      this.context.router.push('/')
    }
    this.props.systemFetch()
    this.props.computerFetch()
    this.props.connectionFetch()
  }

  onSystemSelect (systemIp, systemName) {
    this.setState({ selectedSystem: { systemIp, systemName } })
  }

  onComputerSelect (computerIp, computerName) {
    const index = findIndex(this.state.selectedComputers, (o) => { return o.computerIp === computerIp })
    if(index === -1) {
      const newState = this.state.selectedComputers
      newState.push({ computerIp, computerName })
      this.setState({ selectedComputers: newState })
    } else {
      const newState = this.state.selectedComputers
      newState.splice(index, 1)
      this.setState({ selectedComputers: newState })
    }
  }

  onConnectionAdd () {
    if (this.state.selectedSystem.systemIp !== '' && this.state.selectedSystem.systemName !== '' && this.state.selectedComputers.length > 0) {
      this.props.connectionAdd(this.state.selectedSystem, this.state.selectedComputers)
      this.setState({ selectedSystem: { systemName: '', systemIp: '' }, selectedComputers: [] })
      setTimeout(() => {
        this.props.connectionFetch()
      }, 200)
      setTimeout(() => {
        this.props.systemFetch()
      }, 200)
      setTimeout(() => {
        this.props.computerFetch()
      }, 200)
      alert('Connection successfully created')
    }
  }

  render () {
    const { systems, computers, connections } = this.props
    const { selectedSystem, selectedComputers } = this.state
    return (
      <Connection
        systems={systems}
        computers={computers}
        connections={connections}
        selectedSystem={selectedSystem}
        selectedComputers={selectedComputers}
        onComputerSelect={this.onComputerSelect}
        onSystemSelect={this.onSystemSelect}
        onConnectionAdd={this.onConnectionAdd}
      />
    )
  }
}

ConnectionContainer.contextTypes = {
  router: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(ConnectionContainer)
