import React from 'react'
import PropTypes from 'prop-types'
import DuckImage from './assets/1.png'
import './Header.scss'

const Header = () => (
	<div className="header">
	
		<img  alt='University Rostock' className='duck' src={DuckImage} />
	</div>
)

// Header.propTypes = {
//   : PropTypes.
// }

export default Header
