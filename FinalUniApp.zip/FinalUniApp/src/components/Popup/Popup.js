import React from 'react'
import PropTypes from 'prop-types'
import './Popup.scss'

const Popup = ({
  onPopupClose, header,
  opened, children
}) => (
  <div className={`${opened ? 'popup-overlay' : 'popup-closed'}`}>
    <div className='popup'>
      <div className='row'>
        <div className='col-8 offset-2'>{header}</div>
        <div className='col-2 popup-close' onClick={onPopupClose}>&#215;</div>
      </div>
      <div className='row'>
        <div className='col-12' style={{ marginTop: '20px' }}>
          {children}
        </div>
      </div>
    </div>
  </div>
)

export default Popup
