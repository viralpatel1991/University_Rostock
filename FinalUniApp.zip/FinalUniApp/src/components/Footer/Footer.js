import React from 'react'
import PropTypes from 'prop-types'
import './Footer.scss'

const Footer = () => (
   <div className="footer">
		<h3 style={{textAlign : 'right'}}> Wel-come to AVA Lab</h3>
	</div>
)

// Header.propTypes = {
//   : PropTypes.
// }

export default Footer
