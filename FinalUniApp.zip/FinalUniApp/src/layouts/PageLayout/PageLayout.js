import React from 'react'
import { IndexLink, Link } from 'react-router'
import PropTypes from 'prop-types'
import {Nav , NavItem} from 'react-bootstrap'
import './PageLayout.scss'
import Header from 'components/Header'
import Footer from 'components/Footer'

export const PageLayout = ({ children }) => (
  <div>
    <Header/>
    <Nav justified activeKey={1} onSelect={this.handleSelect} style={{margin:0, fontSize:'17px'}} >
      <NavItem eventKey={1}><IndexLink to='/'>Home</IndexLink></NavItem>
      <NavItem eventKey={2}><Link to='/terminal'>Terminal</Link></NavItem>
      <NavItem eventKey={3}><Link to='/vm'>Virtual Machine </Link></NavItem>
      <NavItem eventKey={5}><Link to='/connections'>Show Connection</Link></NavItem>
    </Nav>
    <div className='page-layout__viewport'>
      { children }
    </div>
    <Footer/>
  </div>
)
PageLayout.propTypes = {
  children: PropTypes.node,
}

export default PageLayout
