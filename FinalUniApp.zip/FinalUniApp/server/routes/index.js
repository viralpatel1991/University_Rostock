const express = require('express')
const router = express.Router()
const fs = require('fs')
const findIndex = require('lodash/findIndex')
const filter = require('lodash/filter')
const isEqual = require('lodash/isEqual')
const remove = require('lodash/remove')

const fileLocation = () => {
  if (!process.env.PWD) {
    process.env.PWD = process.cwd();
  }
}
 
fileLocation()

const readDatabase = (database) => {
  const contents = fs.readFileSync(`${process.env.PWD}/server/${database}.json`)
  return JSON.parse(contents)
}

const writeDatabase = (database, action, data) => {
  const contents = fs.readFileSync(`${process.env.PWD}/server/${database}.json`)
  const contentsJSON = JSON.parse(contents)
  console.log(contentsJSON + 'writeDatabase'+ database)
  if (action === 'add') {
    if (database === 'terminals') {
      if(findIndex(contentsJSON, (terminal) => { return terminal.terminalIp === data.terminalIp || terminal.terminalName === data.terminalName }) === -1) {
        contentsJSON.push(data)
        const dataToSave = JSON.stringify(contentsJSON)
        fs.writeFile(`${process.env.PWD}/server/${database}.json`, dataToSave, (err) => {
          if(err) {
            console.log(err)
          } else {
            console.log('saved')
          }
        })
        return dataToSave
      } else {
        return { contentsJSON, message: 'Record duplicated' }
      }
    } else if (database === 'vms') {
      if(findIndex(contentsJSON, (vm) => { return vm.vmIp === data.vmIp || vm.vmName === data.vmName }) === -1) {
        contentsJSON.push(data)
        const dataToSave = JSON.stringify(contentsJSON)
        fs.writeFile(`${process.env.PWD}/server/${database}.json`, dataToSave, (err) => {
          if(err) {
            console.log(err)
          } else {
            console.log('saved')
          }
        })
        return dataToSave
      } else {
        return { contentsJSON, message: 'Record duplicated' }
      }
    } else if (database === 'connections') {
      if(findIndex(contentsJSON, (connection) => { return connection.terminalData.terminalIp === data.terminalData.terminalIp }) === -1) {
        contentsJSON.push(data)

        const dataToSave = JSON.stringify(contentsJSON)
        console.log(dataToSave + 'data1')
        fs.writeFile(`${process.env.PWD}/server/${database}.json`, dataToSave, (err) => {
          if(err) {
            console.log(err)
          } else {
            console.log('saved')
          }
        })
        return dataToSave
      } else {
        console.log('222222')

        const toReturn = updateConnections('add', 'vm', { terminalIp: data.terminalData.terminalIp, vms: data.vms } )
        return { toReturn }
      }
    }
  } else if (action === 'remove') {
    console.log(contentsJSON  +'remove')

    const indexToRemove = findIndex(contentsJSON, (object) => { return isEqual(object, data) })
    console.log(indexToRemove  +'index')

    if(indexToRemove !== -1) {
      contentsJSON.splice(indexToRemove, 1)
      const dataToSave = JSON.stringify(contentsJSON)
      console.log(dataToSave + 'deleteterminal')
      fs.writeFile(`${process.env.PWD}/server/${database}.json`, dataToSave, (err) => {
        if(err) {
          console.log(err)
        } else {
          console.log('saved')
        }
      })
      return dataToSave
    } else {
      const dataToSave = contentsJSON
      return { dataToSave, message: 'Record not found' }
    }
  } else if (action === 'replace') {
    const dataToSave = JSON.stringify(data)
    fs.writeFile(`${process.env.PWD}/server/${database}.json`, dataToSave, (err) => {
      if(err) {
        console.log(err)
      } else {
        console.log('saved')
      }
    })
    return dataToSave
  }
}

const updateConnections = (action, type, data) => {
  const contents = fs.readFileSync(`${process.env.PWD}/server/connections.json`)
  const contentsJSON = JSON.parse(contents)
  console.log(contentsJSON + "updateConnections")
  if(action === 'remove') {
    if(type === 'terminal') {
      indexToRemove = findIndex(contentsJSON, (o) => { return o.terminalData.terminalIp === data.terminalIp })
      console.log(indexToRemove + "index updateConnections")
      if(indexToRemove !== -1) {
        contentsJSON.splice(indexToRemove, 1)
        const dataToSave = JSON.stringify(contentsJSON)
        fs.writeFile(`${process.env.PWD}/server/connections.json`, dataToSave, (err) => {
          if(err) {
            console.log(err)
          } else {
            console.log('saved')
          }
        })
        return dataToSave
      }
    } else if (type === 'vm') {
      const findArr = contentsJSON.map((item, key) => {
        if(item.vms.find((o) => { return o.vmIp === data.vmIp } )) {
          return true
        }
      })

      const indexToRemove = findIndex(findArr, (o) => { return o === true })
      if (indexToRemove !== -1) {
        const vmIndex = findIndex(contentsJSON[indexToRemove].vms, (o) => { return o.vmIp === data.vmIp })
        contentsJSON[indexToRemove].vms.splice(vmIndex, 1)
        const dataToSave = JSON.stringify(contentsJSON)
        console.log(dataToSave +'222222')

        fs.writeFile(`${process.env.PWD}/server/connections.json`, dataToSave, (err) => {
          if(err) { +
            console.log(err)
          } else {
            console.log('saved')
          }
        })
        return dataToSave
      }
    }
  } else if (action === 'add') {
    const indexToModify = findIndex(contentsJSON, (o) => { return o.terminalData.terminalIp === data.terminalIp })
    console.log("VM data = "+ data.vms)
    console.log("index = " + indexToModify)
    if (indexToModify !== -1) {
      console.log("oldData = " + contentsJSON[indexToModify].vms)
      const newData = contentsJSON[indexToModify].vms.concat(data.vms)
      contentsJSON[indexToModify].vms = newData
      console.log("NewData = " + newData)
      const dataToSave = JSON.stringify(contentsJSON)
      fs.writeFile(`${process.env.PWD}/server/connections.json`, dataToSave, (err) => {
        if(err) {
          console.log(err)
        } else {
          console.log('saved')
        }
      })
      return dataToSave
    }
  }
}

const validateIpAddress = (ipaddress) => {
  const ipFormat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
  return ipaddress.match(ipFormat)
}

const sendError = (res, message) => {
  res.json({
    status: 0,
    error: message
  })
}

const sendSuccess = (res, params = {}) => {
  res.json({
   params
  })
}

router.post('/addTerminal', (req, res) => {
  const { terminalIp, terminalName, key } = req.body
  if (!checkAuth(key)) {
    sendError(res, 'Invalid auth key')
  } else {
    if(!terminalIp || !terminalName) {
      sendError(res, 'Invalid input data')
    } else {
      if(terminalName.length < 1 || !validateIpAddress(terminalIp) || !/[a-z]/i.test(terminalName)) {
        sendError(res, 'Invalid input data')
      } else {
        const dbResult = writeDatabase('terminals', 'add', { terminalIp, terminalName })
        if(!dbResult.message) {
          sendSuccess(res, dbResult)
        } else {
          sendError(res, dbResult)
        }
      }
    }
  }
})

router.post('/removeTerminal', (req, res) => {
  const { terminalIp, terminalName, key } = req.body
  if (!checkAuth(key)) {
    sendError(res, 'Invalid auth key')
  } else {
    if(!terminalIp || !terminalName) {
      sendError(res, 'Invalid input data')
    } else {
      if(terminalName.length < 1 || !validateIpAddress(terminalIp)) {
        sendError(res, 'Invalid input data')
      } else {
        const dbResult = writeDatabase('terminals', 'remove', { terminalIp, terminalName })
        updateConnections('remove', 'terminal', { terminalIp, terminalName })
        if(!dbResult.message) {
          sendSuccess(res, dbResult)
        } else {
          sendError(res, dbResult)
        }
      }
    }
  }
})

router.post('/addVm', (req, res) => {
  const { vmIp, vmName, key } = req.body
  if (!checkAuth(key)) {
    sendError(res, 'Invalid auth key')
  } else {
    if(!vmIp || !vmName) {
      sendError(res, 'Invalid input data')
    } else {
      if(vmName.length < 1 || !validateIpAddress(vmIp) || !/[a-z]/i.test(vmName)) {
        sendError(res, 'Invalid input data')
      } else {
        const dbResult = writeDatabase('vms', 'add', { vmIp, vmName })
        if(!dbResult.message) {
          sendSuccess(res, dbResult)
        } else {
          sendError(res, 'Problem with db')
        }
      }
    }
  }
})

router.post('/removeVm', (req, res) => {
  const { vmIp, vmName, key } = req.body
  if (!checkAuth(key)) {
    sendError(res, 'Invalid auth key')
  } else {
    if(!vmIp || !vmName) {
      sendError(res, 'Invalid input data')
    } else {
      if(vmName.length < 1 || !validateIpAddress(vmIp)) {
        sendError(res, 'Invalid input data')
      } else {
        const dbResult = writeDatabase('vms', 'remove', { vmIp, vmName })
        updateConnections('remove', 'vm', { vmIp, vmName })
        if(!dbResult.message) {
          sendSuccess(res, dbResult)
        } else {
          sendError(res, 'Problem with db')
        }
      }
    }
  }
})
router.post('/addTerminalToConnection', (req, res) => {
  const { terminalToSelectedVmAddIp, terminalToSelectedVmAddName, selectedVmName, selectedVmIp,type, key } = req.body
  if (!checkAuth(key)) {
    sendError(res, 'Invalid auth key')
  } else {
    if(!terminalToSelectedVmAddIp || !terminalToSelectedVmAddName || !selectedVmName || !selectedVmIp || !type) {
      sendError(res, 'Invalid input data')
    } else {
      const connectionsDatabase = readDatabase('connections')
      const connectionToChange = findIndex(connectionsDatabase, (o) => { return o.terminalData.terminalIp === terminalToSelectedVmAddIp && o.terminalData.terminalName === terminalToSelectedVmAddName })

      if (connectionToChange !== -1) {
       connectionsDatabase[connectionToChange].vms.push({ vmIp: selectedVmIp, vmName: selectedVmName, type:type })
        writeDatabase('connections', 'replace', connectionsDatabase)
      } else {
        let passed = true
        const vms = [{ vmName: selectedVmName, vmIp: selectedVmIp, type : type }]
        vms.map((vm) => {
          if(vm.vmIp.length < 1 || !validateIpAddress(vm.vmIp) || vm.vmName.length < 1) {
            passed = false
          }
        })
        if(terminalToSelectedVmAddName.length < 1 || !validateIpAddress(terminalToSelectedVmAddIp)) {
          passed = false
        }
        if (passed) {
          writeDatabase('connections', 'add', { terminalData: { terminalName: terminalToSelectedVmAddName, terminalIp: terminalToSelectedVmAddIp }, vms })
        }
      }

      const vmDatabase = readDatabase('vms')
      const dbResult = vmDatabase
      if(!dbResult.message) {
        sendSuccess(res, dbResult)
      } else {
        sendError(res, dbResult)
      }
    }
  }
})



router.post('/addVmToConnection', (req, res) => {
  const { vms, selectedTerminalName, selectedTerminalIp,key } = req.body
  if (!checkAuth(key)) {
    sendError(res, 'Invalid auth key')
  } else {
    if(!vms || !selectedTerminalName || !selectedTerminalIp) {
      sendError(res, 'Invalid input data')
    } else {

      let passed = true

        vms.map((vm) => {
          if(vm.vmIp.length < 1 || !validateIpAddress(vm.vmIp) || vm.vmName.length < 1) {
            passed = false
          }
        })
        if(selectedTerminalName.length < 1 || !validateIpAddress(selectedTerminalIp)) {
          passed = false
        }
        if (passed) {
          writeDatabase('connections', 'add', { terminalData: { terminalName: selectedTerminalName, terminalIp: selectedTerminalIp }, vms})
        }
  }

      const terminalDatabase = readDatabase('terminals')
      const dbResult = terminalDatabase
      if(!dbResult.message) {
        sendSuccess(res, dbResult)
      } else {
        sendError(res, dbResult)
      }
    }
  })

router.post('/removeConnectedVm', (req, res) => {
  const { selectedTerminalName, selectedTerminalIp, vmName, vmIp, key } = req.body
  if (!checkAuth(key)) {
    sendError(res, 'Invalid auth key')
  } else {
    if(!selectedTerminalName || !selectedTerminalIp || !vmName || !vmIp) {
      sendError(res, 'Invalid input data')
    } else {
      const connectionsDatabase = readDatabase('connections')
      const connectionToChange = findIndex(connectionsDatabase, (o) => { return o.terminalData.terminalIp === selectedTerminalIp && o.terminalData.terminalName === selectedTerminalName })
      if (connectionToChange !== -1) {
        const vmToRemove = findIndex(connectionsDatabase[connectionToChange].vms, (o) => { return o.vmIp === vmIp && o.vmName === vmName })
        console.log(connectionsDatabase[connectionToChange].vms[vmToRemove])
        const vmsChanged = connectionsDatabase[connectionToChange].vms.splice(vmToRemove, 1)
        writeDatabase('connections', 'replace', connectionsDatabase)
      }

      const terminalDatabase = readDatabase('terminals')
      const dbResult = terminalDatabase
      if(!dbResult.message) {
        sendSuccess(res, dbResult)
      } else {
        sendError(res, dbResult)
      }
    }
  }
})

router.post('/removeConnectedTerminal', (req, res) => {
  const { selectedVmName, selectedVmIp, terminalName, terminalIp, key } = req.body
  if (!checkAuth(key)) {
    sendError(res, 'Invalid auth key')
  } else {
    if(!selectedVmName || !selectedVmIp || !terminalName || !terminalIp) {
      sendError(res, 'Invalid input data')
    } else {
      const connectionsDatabase = readDatabase('connections')
      const connectionToChange = findIndex(connectionsDatabase, (o) => { return o.terminalData.terminalIp === terminalIp && o.terminalData.terminalName === terminalName })

      if (connectionToChange !== -1) {
        const vmToRemove = findIndex(connectionsDatabase[connectionToChange].vms, (o) => { return o.vmIp === selectedVmIp && o.vmName === selectedVmName})
        connectionsDatabase[connectionToChange].vms.splice(vmToRemove, 1)
        console.log(connectionsDatabase)
        writeDatabase('connections', 'replace', connectionsDatabase)
      }

      const vmDatabase = readDatabase('vms')
      const dbResult = vmDatabase
      if(!dbResult.message) {
        sendSuccess(res, dbResult)
      } else {
        sendError(res, dbResult)
      }
    }
  }
})



router.post('/changeVm', (req, res) => {
  const {
    selectedVmIp,
    selectedVmName,
    selectedVmNameChanged,
    selectedVmIpChanged,
    key
  } = req.body

  if (!checkAuth(key)) {
    sendError(res, 'Invalid auth key')
  } else {
    if(!selectedVmIp || !selectedVmName || !selectedVmNameChanged && !selectedVmIpChanged) {
      sendError(res, 'Invalid input data')
    } else {
      const vmDatabase = readDatabase('vms')

      const vmToChange = findIndex(vmDatabase, (o) => { return o.vmName === selectedVmName && o.vmIp === selectedVmIp })

      if (vmToChange !== -1) {
        if (selectedVmNameChanged) {
          vmDatabase[vmToChange].vmName = selectedVmNameChanged
        }
        if (selectedVmIpChanged) {
          vmDatabase[vmToChange].vmIp = selectedVmIpChanged
        }
      }

      const dbResult = writeDatabase('vms', 'replace', vmDatabase)

      const connectionsDatabase = readDatabase('connections')
      const connectionsToChange = connectionsDatabase.reduce((acc, element, index) => {
        if (findIndex(element.vms, (o) => { return o.vmName === selectedVmName && o.vmIp === selectedVmIp }) !== -1) {
          acc.push(index)
        }
        return acc;
      }, [])

      if (connectionsToChange) {
        connectionsToChange.map((index) => {
          const indexX = findIndex(connectionsDatabase[index].vms, (o) => { return o.vmName === selectedVmName && o.vmIp === selectedVmIp })
          if (selectedVmNameChanged) {
            connectionsDatabase[index].vms[indexX].vmName = selectedVmNameChanged
          }
          if (selectedVmIpChanged) {
            connectionsDatabase[index].vms[indexX].vmIp = selectedVmIpChanged
          }
        })
      }

      writeDatabase('connections', 'replace', connectionsDatabase)
      if(!dbResult.message) {
        sendSuccess(res, dbResult)
      } else {
        sendError(res, dbResult)
      }
    }
  }
})

router.post('/changeTerminal', (req, res) => {
  const {
    selectedTerminalIp,
    selectedTerminalName,
    selectedTerminalNameChanged,
    selectedTerminalIpChanged,
    key
  } = req.body

  if (!checkAuth(key)) {
    sendError(res, 'Invalid auth key')
  } else {
    if(!selectedTerminalIp || !selectedTerminalName || !selectedTerminalNameChanged && !selectedTerminalIpChanged) {
      sendError(res, 'Invalid input data')
    } else {
      const terminlDatabase = readDatabase('terminals')

      const terminalToChange = findIndex(terminlDatabase, (o) => { return o.terminalName === selectedTerminalName && o.terminalIp === selectedTerminalIp })

      if (terminalToChange !== -1) {
        if (selectedTerminalNameChanged) {
          terminlDatabase[terminalToChange].terminalName = selectedTerminalNameChanged
        }
        if (selectedTerminalIpChanged) {
          terminlDatabase[terminalToChange].terminalIp = selectedTerminalIpChanged
        }
      }

      const dbResult = writeDatabase('terminals', 'replace', terminlDatabase)

      const connectionsDatabase = readDatabase('connections')
      const connectionsToChange = connectionsDatabase.reduce((acc, element, index) => {
        if (element.terminalData.terminalName === selectedTerminalName && element.terminalData.terminalIp === selectedTerminalIp)
          acc.push(index);
        return acc;
      }, [])

      if (connectionsToChange) {
        connectionsToChange.map((index) => {
          if (selectedTerminalNameChanged) {
            connectionsDatabase[index].terminalData.terminalName = selectedTerminalNameChanged
          }
          if (selectedTerminalIpChanged) {
            connectionsDatabase[index].terminalData.terminalIp = selectedTerminalIpChanged
          }
        })
      }

      writeDatabase('connections', 'replace', connectionsDatabase)
      if(!dbResult.message) {
        sendSuccess(res, dbResult)
      } else {
        sendError(res, dbResult)
      }
    }
  }
})

router.get('/getData', (req, res) => {
  const { db, key } = req.query
  if (checkAuth(key)) {
    if(db === 'vms' || db === 'terminals' || db === 'connections') {
      const databaseContent = readDatabase(db)
      sendSuccess(res, databaseContent)
    } else {
      sendError(res, 'Invalid input data')
    }
  } else {
    sendError(res, 'Invalid auth key')
  }
})

router.post('/login', (req, res) => {
  const { login, password } = req.body
  const databaseContent = readDatabase('users')
  const user = findIndex(databaseContent, (o) => { return o.login === login && o.password === password })
  if (user !== -1) {
    sendSuccess(res, databaseContent[user].key)
  } else {
    sendError(res, 'User and/or password wrong')
  }
})

router.get('/getkey', (req,res) => {
    const databaseContent1 = readDatabase('users')
    sendSuccess(res, databaseContent1[0].key)
       
})

router.post('/changeKey', (req,res) => {
  const { key } = req.body
  const databaseContent = readDatabase('users')
  databaseContent[0].key = key;
  const dataToSave = JSON.stringify(databaseContent)
    fs.writeFile(`${process.env.PWD}/server/users.json`, dataToSave, (err) => {
      if(err) {
        console.log(err)
      } else {
        console.log('saved')
      }
    })
  return dataToSave
})



const checkAuth = (key) => {
  const databaseContent = readDatabase(`users`)
  const user = findIndex(databaseContent, (o) => { return o.key === key })
  return user !== -1
}

module.exports = router